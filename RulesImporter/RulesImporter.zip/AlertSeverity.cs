﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SentinelScheduledAlerts
{
    public enum AlertSeverity
    {
        High,
        Informational,
        Low,
        Medium        

    }
   
}
